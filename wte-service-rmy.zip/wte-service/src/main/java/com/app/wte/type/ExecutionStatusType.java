package com.app.wte.type;

public enum ExecutionStatusType {

	IN_PROGRESS,
	COMPLETED,
	ERROR;
}
