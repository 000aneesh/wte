package com.app.wte.dao;

import com.app.wte.model.DBValidationResponse;

public interface DBValidationDao {

	public DBValidationResponse getStageOfSourceFile(String str); 

	
}
