package com.excelDemo.CP.model;

public class UtilizationModel {

	private String custId;
	private String projectId;
	private String associateId;
	private String onOff;
	private String billedHrs;
	private String avlHrs;
	private String billedFte;
	private String monthYear;
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getAssociateId() {
		return associateId;
	}
	public void setAssociateId(String associateId) {
		this.associateId = associateId;
	}
	public String getOnOff() {
		return onOff;
	}
	public void setOnOff(String onOff) {
		this.onOff = onOff;
	}
	public String getBilledHrs() {
		return billedHrs;
	}
	public void setBilledHrs(String billedHrs) {
		this.billedHrs = billedHrs;
	}
	public String getAvlHrs() {
		return avlHrs;
	}
	public void setAvlHrs(String avlHrs) {
		this.avlHrs = avlHrs;
	}
	public String getBilledFte() {
		return billedFte;
	}
	public void setBilledFte(String billedFte) {
		this.billedFte = billedFte;
	}
	public String getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
	public UtilizationModel(String custId,String monthYear, String projectId, String associateId, String onOff,
			String billedHrs, String avlHrs, String billedFte) {
		super();
		this.custId = custId.trim();
		this.projectId = projectId.trim();
		this.associateId = associateId.trim();
		this.onOff = onOff.trim();
		this.billedHrs = billedHrs.trim();
		this.avlHrs = avlHrs.trim();
		this.billedFte = billedFte.trim();
		this.monthYear = monthYear.trim();
	}
	@Override
	public String toString() {
		return "UtilizationModel [custId=" + custId + ", projectId=" + projectId + ", associateId=" + associateId
				+ ", onOff=" + onOff + ", billedHrs=" + billedHrs + ", avlHrs=" + avlHrs
				+ ", billedFte=" + billedFte + ", monthYear=" + monthYear + "]";
	}
	
}
