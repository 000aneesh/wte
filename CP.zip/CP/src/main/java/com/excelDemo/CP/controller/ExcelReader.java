package com.excelDemo.CP.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;

import com.excelDemo.CP.model.CPRAccountHead;
import com.excelDemo.CP.model.Costs;
import com.excelDemo.CP.model.Customer;
import com.excelDemo.CP.model.Employee;
import com.excelDemo.CP.model.FinancialChartModel;
import com.excelDemo.CP.model.HeadCountPayrollModel;
import com.excelDemo.CP.model.ProjDetail;
import com.excelDemo.CP.model.Project;
import com.excelDemo.CP.model.UtilizationModel;


@Component
public class ExcelReader {
	
	public InputStream getInputStream(String fileName)
			throws FileNotFoundException {
		ClassLoader classLoader = this.getClass().getClassLoader();
		InputStream inp = new FileInputStream(new File(classLoader.getResource(
				fileName).getFile()));
		return inp;
	}
	public InputStream getInputStream(File file)
			throws FileNotFoundException {
		InputStream inp = new FileInputStream(file);
		return inp;
	}
	public String[][] getspecificColFromExcel(Workbook wbInput, String sheetName, List<String> reqColHeadingList) {
		Sheet sheet = wbInput.getSheet(sheetName);
		Row headerRow = sheet.getRow(0);
		int rows = sheet.getPhysicalNumberOfRows();
		int cells = sheet.getRow(0).getPhysicalNumberOfCells();
		List<Integer> reqColList = new ArrayList<Integer>();
		
		
		for (int i = 0; i < cells; i++) {
		     Cell headerCell = headerRow.getCell(i);
		     String header = headerCell.getStringCellValue();
		     if(reqColHeadingList.contains(header)){
		     reqColList.add(i);
		     }
		}
		
		int aa=reqColHeadingList.size();
		String[][] excelMatrix = new String[rows][aa];
		Row rowObj;
		Cell cell;
		int colIndex,column=0;

		for (int row = 1; row <= rows; row++) {
			rowObj = sheet.getRow(row);
			column=0;
			if (rowObj != null) {
				Iterator iter = reqColList.iterator();
			      while (iter.hasNext()) {
			    	 colIndex=(Integer) iter.next();
					cell = rowObj.getCell(colIndex);
					if (cell != null) {
						switch (cell.getCellTypeEnum()) {
						case NUMERIC:
							excelMatrix[row][column] = "" + cell.getNumericCellValue();
							break;
						case STRING:
							excelMatrix[row][column] = "" + cell.getStringCellValue();
							break;
						case FORMULA:
							excelMatrix[row][column] = cell.getCellFormula();
							break;
						case BLANK:
							break;
						case BOOLEAN:
							break;
						case ERROR:
							break;
						case _NONE:
							break;
						default:
							break;
						}
						column++;
					}
				}
			}
		}
		
		return excelMatrix;
	}
	

	public List<Customer> setDetailsToCustomer(List<FinancialChartModel> financialChartList) {
		HashMap<String, String> custMap = new HashMap<String, String>();

		List<Customer> customerList = new ArrayList<Customer>();

		// loop for fetching unique customer ids
		for (FinancialChartModel financialChartModel : financialChartList) {
			if (financialChartModel.getCustId() != null) {
				custMap.put(financialChartModel.getCustId().trim(), financialChartModel.getCustDesc().trim());
			}
		}

		for (HashMap.Entry<String, String> entry : custMap.entrySet()) {
			Customer c1 = new Customer();
			c1.setCustomerId(entry.getKey());
			c1.setCustomerDesc(entry.getValue());

			// get current customer's list of details
			List<FinancialChartModel> currCustFCM = financialChartList.stream()
					.filter(p -> p.getCustId().equalsIgnoreCase(entry.getKey())).collect(Collectors.toList());

			// Get unique projs under the current customer
			Map<String, String> projMaps = new HashMap<String, String>();
			projMaps = currCustFCM.stream()
					.collect(Collectors.toMap(FinancialChartModel::getProjId, FinancialChartModel::getProjDesc,((e1, e2) -> e1)));
			
			//------------------------System.out.println("Unique projects for current Customer"+projMaps);
			List<Project> projectList = new ArrayList<Project>();

			// Loop through each projects one by one
			projMaps.entrySet().forEach(entry1 -> {
				// Take 1st proj. Get all entries for that project
				List<FinancialChartModel> currProjAll = financialChartList.stream()
						.filter(p -> p.getProjId().equalsIgnoreCase(entry1.getKey())).collect(Collectors.toList());
				//--------------------------------------System.out.println("get all entries for proj1 of curr customer"+currProjAll);
				// Get distinct monthYear details from the above list.
				Set<String> monthYear = new HashSet<>();
				currProjAll.stream().filter(p -> monthYear.add(p.getMonthYear())).collect(Collectors.toList());

				Project projDetail = new Project();
				projDetail.setProjectId(entry1.getKey());
				projDetail.setProjectDesc(entry1.getValue());

				List<CPRAccountHead> cprAccList = new ArrayList<CPRAccountHead>();
				// loop through each months
				monthYear.forEach(monthYr -> {
					CPRAccountHead cprAccountHead = new CPRAccountHead();
					List<Costs> directCList = new ArrayList<Costs>();
					List<Costs> indirectCList = new ArrayList<Costs>();
					List<Costs> revenueList = new ArrayList<Costs>();
					// loop through each projects list
					currProjAll.forEach(curproj -> {
						// if the month matches,set cost details of that month
						if (monthYr.equalsIgnoreCase(curproj.getMonthYear())) {
							cprAccountHead.setMonthYear(monthYr);
							Costs cost= new Costs();
							cost.setActuals(Double.parseDouble(curproj.getActuals()));
							cost.setCostType(curproj.getAccMidHeadgrp());
							
							if (curproj.getCprAccHead().contains("Direct")) {
								directCList.add(cost);
							} else if (curproj.getCprAccHead().contains("Indirect")) {
								indirectCList.add(cost);
							} else if (curproj.getCprAccHead().contains("Revenue")){
								revenueList.add(cost);
							}

						}
					});
					cprAccountHead.setDirectCosts(directCList);
					cprAccountHead.setIndirectCosts(indirectCList);
					cprAccountHead.setRevenue(revenueList);
					cprAccountHead.setMonthYear(monthYr);
					cprAccList.add(cprAccountHead);
				});

				projDetail.setCprAccountHead(cprAccList);

				projectList.add(projDetail);
			});

			c1.setProjects(projectList);

			customerList.add(c1);
			//System.out.println(c1);
		}

		return customerList;

	}

	public static void getActualsForProject(String monthYear, String projDesc, String acctHeadGroup, List<FinancialChartModel> financialChartList) {

		double actuals = 0;
		
		for(FinancialChartModel financialChart:financialChartList){
			if (financialChart.getProjDesc()!=null && financialChart.getProjDesc().equalsIgnoreCase(projDesc)
					&& financialChart.getMonthYear().equalsIgnoreCase(monthYear)
					&& financialChart.getAccMidHeadgrp().equalsIgnoreCase(acctHeadGroup)) {
				actuals+=Double.parseDouble(financialChart.getActuals());
			}
		}
		
		
	}

	public List<FinancialChartModel> setDetailsToFinancialModel(String[][] excelMatrix) {
		
		int row=excelMatrix.length;
		List<FinancialChartModel> financialChartList = new ArrayList<FinancialChartModel>();
		for(int i=0;i<row;i++){
			if(excelMatrix[i][0]!=null){
			FinancialChartModel financialChart = new FinancialChartModel(excelMatrix[i][0], excelMatrix[i][1],
					excelMatrix[i][2], excelMatrix[i][3], excelMatrix[i][4], excelMatrix[i][5], excelMatrix[i][6],
					excelMatrix[i][7]);
				financialChartList.add(financialChart);
		}
		}
		return financialChartList;
	}

	public List<HeadCountPayrollModel> setDetailsToHeadCount(String[][] excelMatrix) {
		
		int row=excelMatrix.length;
		List<HeadCountPayrollModel> headCountPayrollModelList = new ArrayList<HeadCountPayrollModel>();
		for(int i=0;i<row;i++){
			if(excelMatrix[i][0]!=null){
				HeadCountPayrollModel headCountPayrollModel = new HeadCountPayrollModel(excelMatrix[i][0], excelMatrix[i][1],
					excelMatrix[i][2], excelMatrix[i][3], excelMatrix[i][4], excelMatrix[i][5], excelMatrix[i][6],
					excelMatrix[i][7], excelMatrix[i][8]);
				headCountPayrollModelList.add(headCountPayrollModel);
		}
		}
		return headCountPayrollModelList;
	}
	
	public List<UtilizationModel> setDetailsToUtilization(String[][] excelMatrix) {
		
		int row=excelMatrix.length;
		List<UtilizationModel> utilizationModelList = new ArrayList<UtilizationModel>();
		for(int i=0;i<row;i++){
			if(excelMatrix[i][0]!=null){
				UtilizationModel utilizationModel = new UtilizationModel(excelMatrix[i][0], excelMatrix[i][1],
					excelMatrix[i][2], excelMatrix[i][3], excelMatrix[i][4], excelMatrix[i][5], excelMatrix[i][6],
					excelMatrix[i][7]);
				utilizationModelList.add(utilizationModel);
		}
		}
		return utilizationModelList;
	}

	//Create list of employees.
	public List<Employee> setDetailsToEmployee(List<HeadCountPayrollModel> headCountPayrollModel,
			List<UtilizationModel> utilizationModel) {

		Set<String> empIdList = new HashSet<String>();
		// loop for fetching unique employee ids
		headCountPayrollModel.forEach(headCountPayroll -> {
			if (headCountPayroll.getCustId() != null) {
				empIdList.add(headCountPayroll.getAssociateId());
			}
		});
		List<Employee> employeeLists = new ArrayList<>();
		empIdList.forEach(empId -> {
			// get all entries for the current employee based on associateID
			List<HeadCountPayrollModel> curEmpPayrollList = headCountPayrollModel.stream()
					.filter(p -> p.getAssociateId().equalsIgnoreCase(empId)).collect(Collectors.toList());

			// get all entries for the current employee
			List<UtilizationModel> curEmpUtilizationList = utilizationModel.stream()
					.filter(p -> p.getAssociateId().equalsIgnoreCase(empId)).collect(Collectors.toList());

			Employee employee = new Employee();
			employee.setEmpId(empId);
			List<ProjDetail> projListForcurrEmp = new ArrayList<ProjDetail>();

			// loop curEmpPayrollList and set projects to employees.
			curEmpPayrollList.forEach(currEmployee -> {
				employee.setEmpName(currEmployee.getAssociateName());
				employee.setGrade(currEmployee.getGradeDesc());
				ProjDetail projDetail = new ProjDetail();
				projDetail.setBillability(currEmployee.getBillability());
				projDetail.setProllRegion(currEmployee.getProllRegion());
				projDetail.setProllPerMonth(currEmployee.getProllPerMonth());
				projDetail.setProjId(currEmployee.getProjectId());
				projDetail.setMonthYear(currEmployee.getMonthYear());
				projListForcurrEmp.add(projDetail);
			});

			employee.setProjDetails(projListForcurrEmp);
			// Add utilization details also to the employee object
			projListForcurrEmp.forEach(projsForcurrEmp -> {
				UtilizationModel curEmpUtilization = (UtilizationModel) curEmpUtilizationList.stream()
						.filter(p -> p.getProjectId().equalsIgnoreCase(String.valueOf(projsForcurrEmp.getProjId())))
						.filter(p -> p.getMonthYear().equalsIgnoreCase(projsForcurrEmp.getMonthYear())).findAny().get();

				projsForcurrEmp.setAvlHrs(curEmpUtilization.getAvlHrs());
				projsForcurrEmp.setBilledHrs(curEmpUtilization.getBilledHrs());
				projsForcurrEmp.setOnOff(curEmpUtilization.getOnOff());
				projsForcurrEmp.setBilledFte(curEmpUtilization.getBilledFte());

			});
			
			employeeLists.add(employee);

		});

		return employeeLists;
	}
	
	
	

	public List<Customer> setDetailsToCustomerObj(List<FinancialChartModel> financialChartList,
			List<Employee> employeeList) {
		HashMap<String, String> custMap = new HashMap<String, String>();

		List<Customer> customerList = new ArrayList<Customer>();

		// loop for fetching unique customer ids
		for (FinancialChartModel financialChartModel : financialChartList) {
			if (financialChartModel.getCustId() != null) {
				custMap.put(financialChartModel.getCustId().trim(), financialChartModel.getCustDesc().trim());
			}
		}

		for (HashMap.Entry<String, String> entry : custMap.entrySet()) {
			Customer cust = new Customer();
			cust.setCustomerId(entry.getKey());
			cust.setCustomerDesc(entry.getValue());

			// get current customer's list of details
			List<FinancialChartModel> currCustFCM = financialChartList.stream()
					.filter(p -> p.getCustId().equalsIgnoreCase(entry.getKey())).collect(Collectors.toList());

			// Get unique projs under the current customer
			Map<String, String> projMaps = new HashMap<String, String>();
			projMaps = currCustFCM.stream()
					.collect(Collectors.toMap(FinancialChartModel::getProjId, FinancialChartModel::getProjDesc,((e1, e2) -> e1)));
			
			List<Project> projectList = new ArrayList<Project>();

			// Loop through each projects one by one
			projMaps.entrySet().forEach(entry1 -> {
				// Take 1st proj. Get all entries for that project
				List<FinancialChartModel> currProjAll = financialChartList.stream()
						.filter(p -> p.getProjId().equalsIgnoreCase(entry1.getKey())).collect(Collectors.toList());
				// Get distinct monthYear details from the above list.
				Set<String> monthYear = new HashSet<>();
				currProjAll.stream().filter(p -> monthYear.add(p.getMonthYear())).collect(Collectors.toList());

				Project projDetail = new Project();
				projDetail.setProjectId(entry1.getKey());
				projDetail.setProjectDesc(entry1.getValue());

				List<CPRAccountHead> cprAccList = new ArrayList<CPRAccountHead>();
				// loop through each months
				monthYear.forEach(monthYr -> {
					List<Employee> employeesList = new ArrayList<Employee>();
					CPRAccountHead cprAccountHead = new CPRAccountHead();
					List<Costs> directCList = new ArrayList<Costs>();
					List<Costs> indirectCList = new ArrayList<Costs>();
					List<Costs> revenueList = new ArrayList<Costs>();
					// loop through each projects list
					currProjAll.forEach(curproj -> {
						// if the month matches,set cost details of that month
						if (monthYr.equalsIgnoreCase(curproj.getMonthYear())) {
							cprAccountHead.setMonthYear(monthYr);
							Costs cost= new Costs();
							cost.setActuals(Double.parseDouble(curproj.getActuals()));
							cost.setCostType(curproj.getAccMidHeadgrp());
							
							if (curproj.getCprAccHead().contains("Direct")) {
								directCList.add(cost);
							} else if (curproj.getCprAccHead().contains("Indirect")) {
								indirectCList.add(cost);
							} else if (curproj.getCprAccHead().contains("Revenue")){
								revenueList.add(cost);
							}

						}
					});
					cprAccountHead.setDirectCosts(directCList);
					cprAccountHead.setIndirectCosts(indirectCList);
					cprAccountHead.setRevenue(revenueList);
					cprAccountHead.setMonthYear(monthYr);
					
					//Adding employees to customer object
					employeeList.forEach(employee->{
						Employee emp=new Employee();
						ProjDetail projectDetails = null;
						
						Optional<ProjDetail> projectOptional = employee.getProjDetails().stream()
								.filter(p -> p.getProjId()==Integer.parseInt(entry1.getKey()))
								.filter(p -> p.getMonthYear().equalsIgnoreCase(monthYr)).findFirst();
						if (projectOptional.isPresent()) {
							projectDetails = projectOptional.get();
						}
						if(projectDetails!=null){
							List<ProjDetail> projectDetailsList = new ArrayList<>();
							projectDetailsList.add(projectDetails);
							emp.setEmpId(String.valueOf(employee.getEmpId()));
							emp.setEmpName(employee.getEmpName());
							emp.setGrade(employee.getGrade());
							emp.setProjDetails(projectDetailsList);
							employeesList.add(emp);
						}
					});
					cprAccountHead.setEmployees(employeesList);
					cprAccList.add(cprAccountHead);
				});

				projDetail.setCprAccountHead(cprAccList);

				projectList.add(projDetail);
			});

			cust.setProjects(projectList);

			customerList.add(cust);
			System.out.println(cust);
		}
		return customerList;

	}

}
