package com.excelDemo.CP.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CPRAccountHead implements Comparable<CPRAccountHead> {

	private List<Costs> directCosts = new ArrayList<Costs>();
	private List<Costs> indirectCosts = new ArrayList<Costs>();
	private List<Costs> revenue = new ArrayList<Costs>();
	private List<Employee> employees;
	private String monthYear;

	public List<Costs> getDirectCosts() {
		return directCosts;
	}

	public void setDirectCosts(List<Costs> directCosts) {
		this.directCosts = directCosts;
	}

	public List<Costs> getIndirectCosts() {
		return indirectCosts;
	}

	public void setIndirectCosts(List<Costs> indirectCosts) {
		this.indirectCosts = indirectCosts;
	}

	public String getMonthYear() {
		return monthYear;
	}

	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	public List<Costs> getRevenue() {
		return revenue;
	}

	public void setRevenue(List<Costs> revenue) {
		this.revenue = revenue;
	}
	
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public int compareTo(CPRAccountHead arg0) {
		String dateToComp = arg0.getMonthYear();
		String dates = getMonthYear();
		Date date1 = null, date2 = null;
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy", Locale.getDefault());
		try {
			date1 = format.parse(dateToComp);
			date2 = format.parse(dates);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (date1 == null || date2 == null) {
			return 0;
		}
		return date2.compareTo(date1);
	}

	@Override
	public String toString() {
		return "CPRAccountHead [directCosts=" + directCosts + ", indirectCosts=" + indirectCosts + ", revenue="
				+ revenue + ", employees=" + employees + ", monthYear=" + monthYear + "]";
	}

	}
