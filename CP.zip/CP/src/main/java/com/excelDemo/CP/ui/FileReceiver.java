package com.excelDemo.CP.ui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.excelDemo.CP.controller.ExcelReader;
import com.excelDemo.CP.controller.ExcelWriter;
import com.excelDemo.CP.model.Customer;
import com.excelDemo.CP.model.Employee;
import com.excelDemo.CP.model.FinancialChartModel;
import com.excelDemo.CP.model.HeadCountPayrollModel;
import com.excelDemo.CP.model.UtilizationModel;
import com.excelDemo.CP.util.ExcelConstants;
import com.vaadin.server.FileResource;
import com.vaadin.server.Page;
import com.vaadin.ui.Image;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Upload.Receiver;
import com.vaadin.ui.Upload.SucceededEvent;
import com.vaadin.ui.Upload.SucceededListener;

class FileReceiver implements Receiver, SucceededListener {
	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public File inputFile;
	   	
	public File outputFile;
	    ExcelReader excelReader;
	    ExcelWriter excelWriter;
	    
	    public FileReceiver(ExcelReader excelReader, ExcelWriter excelWriter) {
	    	this.excelReader=excelReader;
	    	this.excelWriter=excelWriter;
		}

		public OutputStream receiveUpload(String filename,
	                                      String mimeType) {
	    	System.out.println("rece"
	    			+ "iveUpload");
	       
	        // Create upload stream
	        FileOutputStream fos = null; // Stream to write to
	        try {
	            // Open the file for writing.
	          inputFile = new File("D:/Projects/Innovation/temp/cp/" + filename);
	            fos = new FileOutputStream(inputFile);
	            
	            
	        } catch (final java.io.FileNotFoundException e) {
	            new Notification("Could not open file<br/>",
	                             e.getMessage(),
	                             Notification.Type.ERROR_MESSAGE)
	                .show(Page.getCurrent());
	            return null;
	        }
	        return fos; // Return the output stream to write to
	    }

	    public void uploadSucceeded(SucceededEvent event) {
	    	System.out.println("uploadSucceeded");
	    	
	        

	    	outputFile =receiveUpload(inputFile);
	    }
	    
	    public File receiveUpload(File file) {
	    	
	    	File out=null;
	    	
	    	System.out.println("receiveUpload : Entry ");
			try {
				Workbook wbInput = null;
			
				System.out.println(file);
				InputStream inp = excelReader.getInputStream(file);
				wbInput = new XSSFWorkbook(inp);

				String[][] excelMatrix = excelReader.getspecificColFromExcel(wbInput, ExcelConstants.SHEET_FINANCIALS,
						ExcelConstants.REQCOL_HEADING_LIST);
				List<FinancialChartModel> financialChartList = excelReader.setDetailsToFinancialModel(excelMatrix);
				String[][] excelMatrix2 = excelReader.getspecificColFromExcel(wbInput,
						ExcelConstants.SHEET_HEADCOUNT_PAYROLL, ExcelConstants.REQCOL_HEADING_LIST2);
				List<HeadCountPayrollModel> headCountPayrollModel = excelReader.setDetailsToHeadCount(excelMatrix2);
				String[][] excelMatrix3 = excelReader.getspecificColFromExcel(wbInput, ExcelConstants.SHEET_UTILIZATION,
						ExcelConstants.REQCOL_HEADING_LIST3);
				List<UtilizationModel> utilizationModel = excelReader.setDetailsToUtilization(excelMatrix3);

				List<Employee> employeeList = excelReader.setDetailsToEmployee(headCountPayrollModel, utilizationModel);
				List<Customer> customers = excelReader.setDetailsToCustomerObj(financialChartList, employeeList);
				System.out.println("customers : "+customers);
				out=excelWriter.buildExcel(customers);
			} catch (IOException e) {
				e.printStackTrace();
			}
			return out;
			
		}
	    
	    
	}