package com.excelDemo.CP.model;

import java.util.ArrayList;
import java.util.List;

public class Project {


	private int projectId;
	private String projectDesc;
	private List<CPRAccountHead> cprAccountHead = new ArrayList<CPRAccountHead>();
	
	public int getProjectId() {
		return projectId;
	}
	public Project(String projectId, String projectDesc) {
		super();
		this.projectId = Integer.parseInt(projectId);
		this.projectDesc = projectDesc;
	}
	public Project() {
	}
	public void setProjectId(String projectId) {
		this.projectId = Integer.parseInt(projectId);
	}
	public String getProjectDesc() {
		return projectDesc;
	}
	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}
	public List<CPRAccountHead> getCprAccountHead() {
		return cprAccountHead;
	}
	public void setCprAccountHead(List<CPRAccountHead> cprAccountHead) {
		this.cprAccountHead = cprAccountHead;
	}
	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectDesc=" + projectDesc + ", cprAccountHead=" + cprAccountHead
				+ "]";
	}
	
	
}
