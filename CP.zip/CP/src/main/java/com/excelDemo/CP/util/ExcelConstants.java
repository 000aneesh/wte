package com.excelDemo.CP.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ExcelConstants {

	public static final List<String> REQCOL_HEADING_LIST = new ArrayList<String>(
			Arrays.asList("CUSTOMER_ID", "CUSTOMER_DESCRIPTION", "PROJECT_ID", "PROJECT_DESCRIPTION",
					"CPR_ACCOUNT_HEAD", "ACCOUNT_MID_HEAD_GROUP", "MONTH_YEAR", "ACTUALS"));
	public static final List<String> REQCOL_HEADING_LIST2 = new ArrayList<String>(
			Arrays.asList("CUSTOMER_ID", "PROJECT_ID", "PROJECT_BILLABILITY", "ASSOCIATE_ID", "ASSOCIATE_NAME",
					"GRADE_DESCRIPTION", "PROLL_PERSON_MONTH", "PROLL_REGION", "PROJECT_BILLABILITY", "MONTH_YEAR"));
	public static final List<String> REQCOL_HEADING_LIST3 = new ArrayList<String>(Arrays.asList("CUSTOMER_ID",
			"PROJECT_ID", "ASSOCIATE_ID", "ON_OFF", "BILLED_HRS", "AVL_HRS", "BILLED_FTE", "MONTH_YEAR"));
	public static final int START_INDEX_OF_PROJ = 2;
	public static final int NUM_OF_ROWS_IN_PROJ = 11;
	public static final String[] MONTHS = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
	public static final String SHEET_FINANCIALS="Financials ChartofAccounts (6)";
	public static final String SHEET_HEADCOUNT_PAYROLL="Headcount per Payroll (7)";
	public static final String SHEET_UTILIZATION="Utilization FTE (8)";
}

