package com.excelDemo.CP.ui;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;

import com.excelDemo.CP.controller.ExcelReader;
import com.excelDemo.CP.controller.ExcelWriter;
import com.vaadin.annotations.Theme;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.navigator.View;
import com.vaadin.server.FileDownloader;
import com.vaadin.server.StreamResource;
import com.vaadin.server.StreamResource.StreamSource;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Panel;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.Upload;
import com.vaadin.ui.Upload.FinishedEvent;
import com.vaadin.ui.Upload.ProgressListener;
import com.vaadin.ui.Upload.StartedEvent;
import com.vaadin.ui.Upload.StartedListener;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;


@SpringView(name = CPUI.VIEW_NAME)
public class CPUI extends CssLayout implements View {

	 public static final String VIEW_NAME = "CPView";
	   
	private static final long serialVersionUID = 1L;
	private Panel springViewDisplay;
	InputStream inp = null;
	OutputStream outputFile = null;
	private VerticalLayout layout;
	
	@Autowired
	ExcelWriter excelWriter;
	@Autowired
	ExcelReader excelReader;

	@PostConstruct
	protected void init() {
		System.out.println("CPUI entry");
    	
		setupLayout();
		addHeader();
		addForm();
		 setSizeFull();
	        addComponent(layout);
	       
		//addActionButtons();
		//layout.setSizeFull();
		//setContent(layout);

		
		
	}

	private void addActionButtons() {
		// TODO Auto-generated method stub

	}

	private void addForm() {

		HorizontalLayout formLayout = new HorizontalLayout();
		formLayout.setWidth("80%");

		// Show uploaded file in this placeholder

		// Implement both receiver that saves upload in a file and
		// listener for successful upload

		FileReceiver receiver = new FileReceiver(excelReader,excelWriter);

		// Create the upload with a caption and set receiver later
		final Upload upload = new Upload("", receiver);
		upload.setButtonCaption("Start Upload");
		upload.addSucceededListener(receiver);

		// Prevent too big downloads
		final long UPLOAD_LIMIT = 1000000l;
		upload.addStartedListener(new StartedListener() {
			@Override
			public void uploadStarted(StartedEvent event) {
				System.out.println("uploadStarted");
				if (event.getContentLength() > UPLOAD_LIMIT) {
					Notification.show("Too big file", Notification.Type.ERROR_MESSAGE);
					upload.interruptUpload();
				}
			}
		});

		// Check the size also during progress
		upload.addProgressListener(new ProgressListener() {
			@Override
			public void updateProgress(long readBytes, long contentLength) {
				if (readBytes > UPLOAD_LIMIT) {
					Notification.show("Too big file", Notification.Type.ERROR_MESSAGE);
					upload.interruptUpload();
				}
			}
		});
		
		upload.addFinishedListener(new Upload.FinishedListener() {
			
			@Override
			public void uploadFinished(FinishedEvent event) {
				// TODO Auto-generated method stub
				Button downloadButton = new Button("Download image");
				formLayout.addComponent(downloadButton);
				
				StreamResource myResource = createResource();
		        FileDownloader fileDownloader = new FileDownloader(myResource);
		        fileDownloader.extend(downloadButton);

			}

			private StreamResource createResource() {
				
				return new StreamResource(new StreamSource() {
		            @Override
		            public InputStream getStream() {
		            	try {
							return new FileInputStream(receiver.outputFile);
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return null;
						
		            }
		            	
		            }, "test");
			
			
			
		}
		});
			
		// TODO Auto-generated method stub
		formLayout.setSpacing(false);
		Label uploadLabel = new Label("Upload Your CP sheet");
		uploadLabel.addStyleName(ValoTheme.TEXTFIELD_ALIGN_RIGHT);
		formLayout.setDefaultComponentAlignment(Alignment.MIDDLE_CENTER);
		formLayout.addComponent(uploadLabel);		
		formLayout.addComponent(upload);
		layout.addComponent(formLayout);
		

	}

	private void addOthers() {
		HorizontalLayout formLayout = new HorizontalLayout();
        formLayout.setWidth("80%");

        TextField taskField = new TextField();
        taskField.focus();
        Button addButton = new Button("");

        formLayout.addComponentsAndExpand(taskField);
        formLayout.addComponent(addButton);
        layout.addComponent(formLayout);

        addButton.addStyleName(ValoTheme.BUTTON_PRIMARY);
        addButton.setIcon(VaadinIcons.PLUS);


	}

	private void addHeader() {
		Label header = new Label("Margin Automation");
		header.addStyleName(ValoTheme.LABEL_H3);
		layout.addComponent(header);

	}

	private void setupLayout() {
		// TODO Auto-generated method stub
		layout = new VerticalLayout();
		layout.setDefaultComponentAlignment(Alignment.TOP_CENTER);
	//	setContent(layout);

	}

	private Button createNavigationButton(String caption, final String viewName) {
		Button button = new Button(caption);
		button.addStyleName(ValoTheme.BUTTON_SMALL);
		button.addClickListener(event -> getUI().getNavigator().navigateTo(viewName));
		return button;
	}

	public void showView(View view) {
		// springViewDisplay.setContent((Component) view);
	}

}