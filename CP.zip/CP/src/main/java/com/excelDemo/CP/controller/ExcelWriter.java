package com.excelDemo.CP.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.excelDemo.CP.model.Costs;
import com.excelDemo.CP.model.Customer;
import com.excelDemo.CP.model.Project;
import com.excelDemo.CP.util.ExcelConstants;

@Component
public class ExcelWriter {
	@Value("${excelTempLocOut}")
	String excelTempLocOut;
	private int rowRev = 0, cellIndex = 0;
	//String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
	XSSFWorkbook workbook;

	public File buildExcel(List<Customer> customers) throws IOException {
	workbook = new XSSFWorkbook();	
		customers.forEach(customer -> {

			System.out.println("In ExcelWriter");

			
			XSSFSheet sheet = workbook.createSheet(customer.getCustomerDesc());
			
			//Create a matrix of cells for the excels
			int custProjCount=customer.getProjects().size();
			for(int rowIndex=0;rowIndex<(custProjCount*ExcelConstants.NUM_OF_ROWS_IN_PROJ+7);rowIndex++){
				sheet.createRow(rowIndex);
				for(int colIndex=0;colIndex<16;colIndex++){
					sheet.getRow(rowIndex).createCell(colIndex).setCellValue("");
					}
			}

			// Customer heading
			sheet.getRow(0).getCell(0).setCellValue(customer.getCustomerDesc());
			
			
			// Set Headings
			Row rowHeading = sheet.getRow(1);
			rowHeading.getCell(0).setCellValue("Project/SOW");
			rowHeading.getCell(1).setCellValue("Parameter");
			rowHeading.getCell(2).setCellValue("");
			Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR) % 100;
			int i = 0;
			for (i = 0; i < 12; i++) {
				rowHeading.getCell(i + 3).setCellValue(ExcelConstants.MONTHS[i] + "-" + year);
			}
			rowHeading.createCell(15).setCellValue("FY " + year);
			cellIndex = 3;
			rowRev = 2;
			
			int rowNum = 1;
			
			//Get projects for the customer and set data
			for (Project project : customer.getProjects()) {

				//sort it so that the AccountHead is sorted month wise.
				Collections.sort(project.getCprAccountHead());

				project.getCprAccountHead().forEach(cprAccountHead -> {
					String monthYear = cprAccountHead.getMonthYear();
					//get Cell index to populate month wise
					cellIndex = getCellIndexForRev(monthYear);
					List<Costs> dcList = cprAccountHead.getDirectCosts();
					List<Costs> idcList = cprAccountHead.getIndirectCosts();
					List<Costs> revenueList = cprAccountHead.getRevenue();

					for (int j = 0; j < 8; j++) {
						XSSFRow x=sheet.getRow(rowRev + j);
						x.getCell(cellIndex).setCellValue(0);
					}
					
					//Get employee list in revenue col.
					StringBuilder employeeList = new StringBuilder();;
					cprAccountHead.getEmployees().forEach(employee ->{
						if(employee.getEmpName()!=null){
						employeeList.append(employee.toString()+"\n");
						}
					});
					// setRevenue
					double revCost = 0;
					for (Costs rCost : revenueList) {
						if (rCost.getCostType().contains("Revenue")) {
							revCost = revCost + rCost.getActuals();
							
						}
					}
					//set revenue column and set comments
					Cell revCell=sheet.getRow(rowRev).getCell(cellIndex);
					revCell.setCellValue(revCost);
					if (employeeList.toString() != null && !(employeeList.toString().trim().isEmpty())) {
						XSSFDrawing drawing = sheet.createDrawingPatriarch();
						XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 0, 5, 3, 15);
						XSSFComment comment1 = drawing.createCellComment(anchor);
						comment1.setString(employeeList.toString());
						revCell.setCellComment(comment1);
					}

					// setDirectCost
					double compCost = 0, travelCost = 0, profCost = 0, totDC = 0, totIDC = 0;
					for (Costs dCost : dcList) {
						if (dCost.getCostType().contains("Compensation & Benefits")) {
							compCost = compCost + dCost.getActuals();
							sheet.getRow(rowRev + 1).getCell(cellIndex).setCellValue(compCost);
						} else if (dCost.getCostType().contains("Travel & Entertainment")) {
							travelCost = travelCost + dCost.getActuals();
							sheet.getRow(rowRev + 2).getCell(cellIndex).setCellValue(travelCost);
						} else {
							profCost = profCost + dCost.getActuals();
							sheet.getRow(rowRev + 3).getCell(cellIndex).setCellValue(profCost);
						}
						totDC = compCost + travelCost + profCost;
						sheet.getRow(rowRev + 4).getCell(cellIndex).setCellValue(totDC);

					}

					// setIndirectCost
					double genInfraCost = 0, spHardwrCost = 0, otherCost = 0;
					for (Costs idCost : idcList) {
						if (idCost.getCostType().contains("General Infrastructure")) {
							genInfraCost = genInfraCost + idCost.getActuals();
							sheet.getRow(rowRev + 5).getCell(cellIndex).setCellValue(genInfraCost);
						} else if (idCost.getCostType().contains("Specific Hardware and Software")) {
							spHardwrCost = spHardwrCost + idCost.getActuals();
							sheet.getRow(rowRev + 6).getCell(cellIndex).setCellValue(spHardwrCost);
						} else {
							otherCost = otherCost + idCost.getActuals();
							sheet.getRow(rowRev + 7).getCell(cellIndex).setCellValue(otherCost);
						}
						totIDC = genInfraCost + spHardwrCost + otherCost;
						sheet.getRow(rowRev + 8).getCell(cellIndex).setCellValue(totIDC);

					}
					double profit = revCost - (totIDC + totDC);
					sheet.getRow(rowRev + 9).getCell(cellIndex).setCellValue(profit);
					if (revCost != 0) {
						sheet.getRow(rowRev + 10).getCell(cellIndex)
								.setCellValue(round(((revCost - (totIDC + totDC)) * 100 / revCost), 2) + "%");
					} else {
						sheet.getRow(rowRev + 10).getCell(cellIndex)
								.setCellValue("");
					}
				});
				rowRev = rowRev + ExcelConstants.NUM_OF_ROWS_IN_PROJ;
				rowNum = setHeadings(project, sheet, rowNum);
				
			}

			for (int columnIndex = 0; columnIndex < 16; columnIndex++) {
				sheet.autoSizeColumn(columnIndex);
			}
			
			sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 15));
			sheet.addMergedRegion(new CellRangeAddress(1, 1, 1, 2));	
			
			
			//overall
			sheet.getRow(rowRev).getCell(0).setCellValue("Overall");
			sheet.getRow(rowRev).getCell(1).setCellValue("Revenue - Direct");
			sheet.getRow(rowRev+1).getCell(1).setCellValue("Total Direct Cost");
			sheet.getRow(rowRev+2).getCell(1).setCellValue("Total Indirect Cost");
			sheet.getRow(rowRev+3).getCell(1).setCellValue("Total Profit");
			sheet.getRow(rowRev+4).getCell(1).setCellValue("CP%");
			sheet.addMergedRegion(new CellRangeAddress(rowRev,rowRev+4 , 0, 0));
			sheet.addMergedRegion(new CellRangeAddress(rowRev,rowRev , 1, 2));
			sheet.addMergedRegion(new CellRangeAddress(rowRev+1,rowRev+1 , 1, 2));
			sheet.addMergedRegion(new CellRangeAddress(rowRev+2,rowRev+2 , 1, 2));
			sheet.addMergedRegion(new CellRangeAddress(rowRev+3,rowRev+3 , 1, 2));
			sheet.addMergedRegion(new CellRangeAddress(rowRev+4,rowRev+4 , 1, 2));
			
			int noOfProj = customer.getProjects().size();
			//int l = ExcelConstants.START_INDEX_OF_PROJ;
			int l =2;
			double overallDCost[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			double overallIDCost[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			double overallRev[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			for (i = 0; i < noOfProj; i++) {

				for (int n = 0; n < ExcelConstants.NUM_OF_ROWS_IN_PROJ; n++) {
					double total = 0;
					XSSFRow row = sheet.getRow(n + l);
					
					for (int k = 3; k < 15; k++) {
						XSSFCell cell;
						cell = row.getCell(k);
						//if (cell != null) {
							switch (cell.getCellTypeEnum()) {
							case BOOLEAN:
								break;
							case NUMERIC:
								total = total + cell.getNumericCellValue();
								row.getCell(15).setCellValue(total);
								if(n==0){
									overallRev[k-3]=overallRev[k-3]+cell.getNumericCellValue();
								}
								if(n==4){
									overallDCost[k-3]=overallDCost[k-3]+cell.getNumericCellValue();
								}
								if(n==8){
									overallIDCost[k-3]=overallIDCost[k-3]+cell.getNumericCellValue();
								}
								break;
							case STRING:
								if (n == 10 && k == 14) {
									double revTot = sheet.getRow(l).getCell(15).getNumericCellValue();
									double profTot = sheet.getRow(l + n - 1).getCell(15).getNumericCellValue();
									if (revTot != 0) {
										row.getCell(15).setCellValue(round(((profTot) * 100 / revTot), 2) + "%");
									}
								}
								break;

							}
						//}
					}

				}
				l = l + ExcelConstants.NUM_OF_ROWS_IN_PROJ;
			}
						
			// Overall Section
			double SumOvrallRev = 0, sumOverallDCost = 0, sumoverallIDCost = 0, overallProf = 0;
			XSSFRow row = sheet.getRow(noOfProj * ExcelConstants.NUM_OF_ROWS_IN_PROJ + 2);
			XSSFRow row1 = sheet.getRow(noOfProj * ExcelConstants.NUM_OF_ROWS_IN_PROJ + 3);
			XSSFRow row2 = sheet.getRow(noOfProj * ExcelConstants.NUM_OF_ROWS_IN_PROJ + 4);
			
			// Looping MonthYear index in excel to populate Overall Revenue, costs and profit
			for (int x = 3; x < 15; x++) {
				if (overallRev[x - 3] != 0) {
					row.getCell(x).setCellValue(overallRev[x - 3]);
					SumOvrallRev = SumOvrallRev + overallRev[x - 3];
				}
				if (overallDCost[x - 3] != 0) {
					row1.getCell(x).setCellValue(overallDCost[x - 3]);
					sumOverallDCost = sumOverallDCost + overallDCost[x - 3];
				}
				if (overallIDCost[x - 3] != 0) {
					row2.getCell(x).setCellValue(overallIDCost[x - 3]);
					sumoverallIDCost = sumoverallIDCost + overallIDCost[x - 3];
				}

				overallProf = overallRev[x - 3] - (overallDCost[x - 3] + overallIDCost[x - 3]);
				if (overallProf != 0) {
					sheet.getRow(noOfProj * ExcelConstants.NUM_OF_ROWS_IN_PROJ + 5).getCell(x).setCellValue(overallProf);
				}
				if(overallRev[x - 3]!=0){
					sheet.getRow(noOfProj * ExcelConstants.NUM_OF_ROWS_IN_PROJ + 6).getCell(x).setCellValue(round(((overallProf) * 100 /  overallRev[x - 3] ), 2) + "%");
				}
				
			}
			// Populate sum of overall Rev and Costs.
			row.getCell(15).setCellValue(SumOvrallRev);
			row1.getCell(15).setCellValue(sumOverallDCost);
			row2.getCell(15).setCellValue(sumoverallIDCost);
			sheet.getRow(noOfProj * ExcelConstants.NUM_OF_ROWS_IN_PROJ + 5).getCell(15)
					.setCellValue(SumOvrallRev - (sumOverallDCost + sumoverallIDCost));
			if(SumOvrallRev!=0){
				sheet.getRow(noOfProj * ExcelConstants.NUM_OF_ROWS_IN_PROJ + 6).getCell(15)
				.setCellValue(round(((SumOvrallRev - (sumOverallDCost + sumoverallIDCost)) * 100 /  SumOvrallRev ), 2) + "%");
			}
			
			applyStylesToExcel(sheet,customer.getProjects());
			
		});
		
		/*try {
			
			Button button = new Button("ABC");
			 ByteArrayOutputStream outs = new ByteArrayOutputStream();
			 workbook.write(outs);
			 
			  //create input stream from baos
			  InputStream isFromFirstData = new ByteArrayInputStream(outs.toByteArray()); 
             
			StreamResource resource = new StreamResource(() -> isFromFirstData, "dummy.xlsx");
	        FileDownloader fileDownloader = new FileDownloader(resource);
	        fileDownloader.extend(button);
	        
			FileOutputStream out = new FileOutputStream(new File("D:\\new.xlsx"));
			workbook.write(out);
			out.close();
			System.out.println("Excel written successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		
		ByteArrayOutputStream outs = new ByteArrayOutputStream();
		 try {
			workbook.write(outs);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 File excelOut= new File(excelTempLocOut+new Date().getTime()+".xlsx");
		 if (!excelOut.exists()) {
			 excelOut.createNewFile();
			}
		 try(OutputStream outputStream = new FileOutputStream(excelOut)) {
			 outs.writeTo(outputStream);
		 }
//create input stream from baos
			return excelOut;
	}

	private void applyStylesToExcel(XSSFSheet sheet, List<Project> projects) {
		XSSFFont font0 = workbook.createFont();
		font0.setFontHeightInPoints((short) 10);
		font0.setBold(true);
		XSSFCellStyle styleMainHead = workbook.createCellStyle();
		styleMainHead.setFont(font0);
		styleMainHead.setAlignment(HorizontalAlignment.CENTER);
		styleMainHead.setVerticalAlignment(VerticalAlignment.CENTER);
		styleMainHead.setBorderBottom(BorderStyle.THIN);
		styleMainHead.setBorderLeft(BorderStyle.THIN);
		styleMainHead.setBorderRight(BorderStyle.THIN);
		styleMainHead.setBorderTop(BorderStyle.THIN);
		styleMainHead.setWrapText(true);
		styleMainHead.setFillForegroundColor(new XSSFColor(new java.awt.Color(214, 220, 228)));
		styleMainHead.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		// Set font into style
		XSSFFont font1 = workbook.createFont();
		font1.setFontHeightInPoints((short) 8);
		XSSFCellStyle styleData = workbook.createCellStyle();
		styleData.setFont(font1);
		styleData.setAlignment(HorizontalAlignment.CENTER);
		styleData.setVerticalAlignment(VerticalAlignment.CENTER);
		styleData.setBorderBottom(BorderStyle.THIN);
		styleData.setBorderLeft(BorderStyle.THIN);
		styleData.setBorderRight(BorderStyle.THIN);
		styleData.setBorderTop(BorderStyle.THIN);
		styleData.setWrapText(true);
		
		
		
		XSSFFont font = workbook.createFont();
		font.setFontHeightInPoints((short) 9);
		font.setBold(true);
		XSSFCellStyle styleHeading = workbook.createCellStyle();
		styleHeading.setFont(font);
		styleHeading.setAlignment(HorizontalAlignment.CENTER);
		styleHeading.setVerticalAlignment(VerticalAlignment.CENTER);
		styleHeading.setBorderBottom(BorderStyle.THIN);
		styleHeading.setBorderLeft(BorderStyle.THIN);
		styleHeading.setBorderRight(BorderStyle.THIN);
		styleHeading.setBorderTop(BorderStyle.THIN);
		styleHeading.setWrapText(true);
		//styleHeading.setFillForegroundColor(IndexedColors.BLUE.getIndex());
		//styleHeading.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
		styleHeading.setFillForegroundColor(new XSSFColor(new java.awt.Color(189, 215, 238)));
		styleHeading.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		
		XSSFFont font3 = workbook.createFont();
		font3.setFontHeightInPoints((short) 10);
		font3.setBold(true);
		XSSFCellStyle styleOverall = workbook.createCellStyle();
		styleOverall.setFont(font3);
		styleOverall.setAlignment(HorizontalAlignment.CENTER);
		styleOverall.setVerticalAlignment(VerticalAlignment.CENTER);
		styleOverall.setBorderBottom(BorderStyle.THIN);
		styleOverall.setBorderLeft(BorderStyle.THIN);
		styleOverall.setBorderRight(BorderStyle.THIN);
		styleOverall.setBorderTop(BorderStyle.THIN);
		styleOverall.setWrapText(true);
		styleOverall.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 230, 153)));
		styleOverall.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		
		int l = 2, i, row, col;
		for(i=0;i<16;i++){
			sheet.getRow(0).getCell(i).setCellStyle(styleOverall);
			sheet.getRow(1).getCell(i).setCellStyle(styleHeading);
			
		}

		int noOfProj = projects.size();
		
		for (i = 0; i < noOfProj; i++) {

			for (row = 0; row < ExcelConstants.NUM_OF_ROWS_IN_PROJ; row++) {
				XSSFRow currntRow = sheet.getRow(row + l);

				for (col = 0; col < 16; col++) {
					XSSFCell cell;
					cell = currntRow.getCell(col);
					if(col==0||col==1){
						cell.setCellStyle(styleData);
					}else{
					if (cell != null) {

						if (row == 0 || row == 4 || row == 8 || row == 9 || row == 10) {
							if (row == 9 || row == 10) {
								currntRow.getCell(col - 1).setCellStyle(styleMainHead);
								
							}
							cell.setCellStyle(styleMainHead);
						} else {
							cell.setCellStyle(styleData);
						}

					}
				}}

			}
			l = l + ExcelConstants.NUM_OF_ROWS_IN_PROJ;
		}
		
		for(row=(noOfProj * ExcelConstants.NUM_OF_ROWS_IN_PROJ + 2);row<(noOfProj * ExcelConstants.NUM_OF_ROWS_IN_PROJ + 7);row++){
			for(col=0;col<16;col++){
				sheet.getRow(row).getCell(col).setCellStyle(styleOverall);
			}
		}

	}

	private int getCellIndexForRev(String monthYear) {

		String match = "default";
		for (int i = 0; i < ExcelConstants.MONTHS.length; i++) {
			if (monthYear.contains(ExcelConstants.MONTHS[i])) {
				match = ExcelConstants.MONTHS[i];
				break;
			}
		}
		int cellIndex = 0;
		switch (match) {
		case "Jan":
			cellIndex = 3;
			break;
		case "Feb":
			cellIndex = 4;
			break;
		case "Mar":
			cellIndex = 5;
			break;
		case "Apr":
			cellIndex = 6;
			break;
		case "May":
			cellIndex = 7;
			break;
		case "Jun":
			cellIndex = 8;
			break;
		case "Jul":
			cellIndex = 9;
			break;
		case "Aug":
			cellIndex = 10;
			break;
		case "Sep":
			cellIndex = 11;
			break;
		case "Oct":
			cellIndex = 12;
			break;
		case "Nov":
			cellIndex = 13;
			break;
		case "Dec":
			cellIndex = 14;
			break;
		default:
		}
		return cellIndex;
	}

	private int setHeadings(Project project, XSSFSheet sheet, int rownum) {

		Row row = sheet.getRow(++rownum);
		int cellnum = 0;
		Cell cell = row.getCell(cellnum++);
		cell.setCellValue(project.getProjectDesc());
		sheet.addMergedRegion(new CellRangeAddress(rownum, rownum + 10, 0, 0));

		// revenue
		row.getCell(cellnum).setCellValue("Revenue");
		row.getCell(cellnum + 1).setCellValue("Revenue - Direct");
		// direct cost
		Row row1 = sheet.getRow(++rownum);
		row1.getCell(cellnum).setCellValue("Direct Cost");
		int rw1=rownum;
		sheet.addMergedRegion(new CellRangeAddress(rw1, rw1+3, cellnum, cellnum));
		row1.getCell(cellnum + 1).setCellValue("Compensation & Benefits");
		sheet.getRow(++rownum).getCell(cellnum + 1).setCellValue("Travel & Entertainment");
		sheet.getRow(++rownum).getCell(cellnum + 1).setCellValue("Professional Services/ Other Costs");
		sheet.getRow(++rownum).getCell(cellnum + 1).setCellValue("Total Direct Cost");

		// indirect cost
		Row row5 = sheet.getRow(++rownum);
		row5.getCell(cellnum).setCellValue("Indirect Cost");
		rw1=rownum;
		sheet.addMergedRegion(new CellRangeAddress(rw1, rw1+3, cellnum, cellnum));
		row5.getCell(cellnum + 1).setCellValue("General Infrastructure");
		Row row6 = sheet.getRow(++rownum);
		row6.getCell(cellnum + 1).setCellValue("Specific Hardware and Software");
		Row row7 = sheet.getRow(++rownum);
		row7.getCell(cellnum + 1).setCellValue("Other Cost (AR Int, INR Fx, UBR/RBA)");
		Row row8 = sheet.getRow(++rownum);
		row8.getCell(cellnum + 1).setCellValue("Total Indirect Cost");
		Row row9 = sheet.getRow(++rownum);

		// Profit and CP
		row9.getCell(cellnum).setCellValue("Total Profit");
		sheet.addMergedRegion(new CellRangeAddress(rownum, rownum, 1, 2));
		Row row10 = sheet.getRow(++rownum);
		row10.getCell(cellnum).setCellValue("CP%");
		sheet.addMergedRegion(new CellRangeAddress(rownum, rownum, 1, 2));
		
		return rownum;

	}

	public static double round(double value, int places) {
		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}

	/*
	 * public enum PAGE{ Jan(0), Feb(1), Mar(2), Apr(3), Jan(0), Feb(1), Mar(2),
	 * Apr(3), Jan(0), Feb(1), Mar(2), Apr(3);
	 * 
	 * private final int value;
	 * 
	 * PAGE(final int newValue) { value = newValue; }
	 * 
	 * public int getValue() { return value; } }
	 */
}
