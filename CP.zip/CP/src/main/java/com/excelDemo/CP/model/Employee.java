package com.excelDemo.CP.model;

import java.util.List;

public class Employee {

	private int empId;
	private String empName;
	private String grade;
	private List<ProjDetail> projDetails;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = Integer.parseInt(empId);
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public List<ProjDetail> getProjDetails() {
		return projDetails;
	}
	public void setProjDetails(List<ProjDetail> projDetails) {
		this.projDetails = projDetails;
	}
	@Override
	public String toString() {
		return  empName+"("+empId+")" + projDetails.toString();
	}
	
	
}
