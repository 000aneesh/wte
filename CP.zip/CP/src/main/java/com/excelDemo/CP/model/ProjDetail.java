package com.excelDemo.CP.model;

public class ProjDetail {
	
	private String monthYear;
	private int projId;
	private String prollPerMonth;
	private String prollRegion;
	private String billability;
	private String onOff;
	private String billedHrs;
	private String avlHrs;
	private String billedFte;
	public String getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
	public int getProjId() {
		return projId;
	}
	public void setProjId(String projId) {
		this.projId = Integer.parseInt(projId);
	}
	public String getProllPerMonth() {
		return prollPerMonth;
	}
	public void setProllPerMonth(String prollPerMonth) {
		this.prollPerMonth = prollPerMonth;
	}
	public String getProllRegion() {
		return prollRegion;
	}
	public void setProllRegion(String prollRegion) {
		this.prollRegion = prollRegion;
	}
	public String getBillability() {
		return billability;
	}
	public void setBillability(String billability) {
		this.billability = billability;
	}
	public String getOnOff() {
		return onOff;
	}
	public void setOnOff(String onOff) {
		this.onOff = onOff;
	}
	public String getBilledHrs() {
		return billedHrs;
	}
	public void setBilledHrs(String billedHrs) {
		this.billedHrs = billedHrs;
	}
	public String getAvlHrs() {
		return avlHrs;
	}
	public void setAvlHrs(String avlHrs) {
		this.avlHrs = avlHrs;
	}
	public String getBilledFte() {
		return billedFte;
	}
	public void setBilledFte(String billedFte) {
		this.billedFte = billedFte;
	}
	@Override
	public String toString() {
		return "Allocation:" + billedFte;
	}
	

}
