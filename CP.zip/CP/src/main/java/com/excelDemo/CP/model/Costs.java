package com.excelDemo.CP.model;

public class Costs {

	private String costType;
	private double actuals;

	public String getCostType() {
		return costType;
	}

	public void setCostType(String costType) {
		this.costType = costType;
	}

	public double getActuals() {
		return actuals;
	}

	public void setActuals(double actuals) {
		this.actuals = actuals;
	}

	@Override
	public String toString() {
		return "Costs [costType=" + costType + ", actuals=" + actuals + "]";
	}
}
