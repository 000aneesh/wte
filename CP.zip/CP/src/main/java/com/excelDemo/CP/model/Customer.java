package com.excelDemo.CP.model;

import java.util.ArrayList;
import java.util.List;

public class Customer {


	private int customerId;
	private String customerDesc;
	private List<Project> projects = new ArrayList<Project>();
	
	public List<Project> getProjects() {
		return projects;
	}

	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = Integer.parseInt(customerId);
	}

	public String getCustomerDesc() {
		return customerDesc;
	}

	public void setCustomerDesc(String customerDesc) {
		this.customerDesc = customerDesc;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerDesc=" + customerDesc + ", projects=" + projects + "]";
	}

}
