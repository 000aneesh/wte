package com.excelDemo.CP.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;

import com.excelDemo.CP.controller.ExcelReader;
import com.excelDemo.CP.controller.ExcelWriter;
import com.excelDemo.CP.model.Customer;
import com.excelDemo.CP.model.Employee;
import com.excelDemo.CP.model.FinancialChartModel;
import com.excelDemo.CP.model.HeadCountPayrollModel;
import com.excelDemo.CP.model.UtilizationModel;
import com.excelDemo.CP.util.ExcelConstants;
import com.vaadin.navigator.View;
import com.vaadin.server.FileDownloader;
import com.vaadin.server.Page;
import com.vaadin.server.StreamResource;
import com.vaadin.server.StreamResource.StreamSource;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.Upload;
import com.vaadin.ui.Upload.FinishedEvent;
import com.vaadin.ui.Upload.ProgressListener;
import com.vaadin.ui.Upload.Receiver;
import com.vaadin.ui.Upload.StartedEvent;
import com.vaadin.ui.Upload.StartedListener;
import com.vaadin.ui.Upload.SucceededEvent;
import com.vaadin.ui.Upload.SucceededListener;

@SpringComponent
@Scope(value="prototype")
@SpringView(name = CPUploadView.VIEW_NAME)
public class CPUploadView extends CPUploadLayout implements View{
	
	public static final String VIEW_NAME="CPScreen";
	//@Autowired
	//UI ui;
	UI ui= UI.getCurrent();	
	File outputFile;
	File inputFile;
	@Autowired
	ExcelWriter excelWriter;
	@Autowired
	ExcelReader excelReader;
	//private ProcessingService processingService;
	public CPUploadView() {
		
		addForm();
	}

	
		/*public  void init(UI ui) {
			this.ui=ui;
			
		}
	*/
		private void addForm() {
			
		// Implement both receiver that saves upload in a file and
		// listener for successful upload

		// Create the upload with a caption and set receiver later
		uploadBtn.setReceiver(receiver);
		//uploadBtn = new Upload("", receiver);
		uploadBtn.addSucceededListener(succeededListener);
		 //FileDownloader fileDownloader = new FileDownloader(myResource);
	     //fileDownloader.extend(downloadBtn);

		// Prevent too big downloads
		final long UPLOAD_LIMIT = 1000000l;
		uploadBtn.addStartedListener(new StartedListener() {
			@Override
			public void uploadStarted(StartedEvent event) {
				cross.setVisible(false);
				tick.setVisible(false);
				downloadBtn.setVisible(false);
				System.out.println("uploadStarted");
				
				if (event.getContentLength() > UPLOAD_LIMIT) {
					Notification.show("Too big file", Notification.Type.ERROR_MESSAGE);
					uploadBtn.interruptUpload();
				}
				else{
					progressBar.setValue(0.0f);
					progressBar.setVisible(true);
				}
			}
		});

		// Check the size also during progress
		uploadBtn.addProgressListener(new ProgressListener() {
			@Override
			public void updateProgress(long readBytes, long contentLength) {
				if (readBytes > UPLOAD_LIMIT) {
					Notification.show("Too big file", Notification.Type.ERROR_MESSAGE);
					uploadBtn.interruptUpload();
				}
			}
		});
		
		uploadBtn.addFinishedListener(new Upload.FinishedListener() {
			
			@Override
			public void uploadFinished(FinishedEvent event) {
				StreamResource myResource = createResource();
		        FileDownloader fileDownloader = new FileDownloader(myResource);
		        if(fileDownloader.getExtensions()!=null && fileDownloader.getExtensions().size()>0){
		        	fileDownloader.remove();
		        }
		        fileDownloader.extend(downloadBtn);

			}

			/*private StreamResource createResource() {
				
				return new StreamResource(new StreamSource() {
		            @Override
		            public InputStream getStream() {
		            	try {
							return new FileInputStream(outputFile);
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}
						return null;
						
		            }
		            	
		            }, "CPWorkBookOut.xlsx");
			
			
		
		}*/
		});
		
		/*downloadBtn.addClickListener(event -> {
			StreamResource myResource = createResource();
			FileDownloader fileDownloader = new FileDownloader(myResource);
			if (fileDownloader.getExtensions() != null && fileDownloader.getExtensions().size() > 0) {
				fileDownloader.remove();
			}
			fileDownloader.extend(downloadBtn);

		});*/
		

		detailViewBtn.addClickListener(event -> {
			//getUI().getNavigator().navigateTo(ExcelConstants.DETAILSVIEW);
	});
		
		
	}
	
	Receiver receiver = new Receiver() {

		private static final long serialVersionUID = 1L;

		@Override
		public OutputStream receiveUpload(String filename, String mimeType) {

			System.out.println("receiveUpload");
			downloadBtn.setVisible(false);
			// Create upload stream
			FileOutputStream fos = null; // Stream to write to
			try {
				// Open the file for writing.
				inputFile = new File("D:/Projects/Innovation/temp/cp/" + filename);
				fos = new FileOutputStream(inputFile);

			} catch (final java.io.FileNotFoundException e) {
				new Notification("Could not open file<br/>", e.getMessage(), Notification.Type.ERROR_MESSAGE)
						.show(Page.getCurrent());
				return null;
			}
			
			return fos; // Return the output stream to write to

		}
	};
	SucceededListener succeededListener = new SucceededListener() {

		private static final long serialVersionUID = 1L;

		@Override
		public void uploadSucceeded(SucceededEvent event) {
			System.out.println("uploadSucceeded");

			receiveUpload(inputFile);
			
		}
		
	};

	public File receiveUpload(File file) {
    	
		 UI.getCurrent().setPollInterval(500);
    	System.out.println("receiveUpload : Entry ");
		
			new Thread (){
				public void run(){
					try {
					File out=null;
			    		
			
			Workbook wbInput = null;
		
			System.out.println(file);
			InputStream inp = excelReader.getInputStream(file);
			wbInput = new XSSFWorkbook(inp);
			progressBar.setCaption("Processing..");
			progressBar.setIndeterminate(false);
			
			ui.access(() -> progressBar.setValue(0.1f));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			String[][] excelMatrix = excelReader.getspecificColFromExcel(wbInput, ExcelConstants.SHEET_FINANCIALS,
					ExcelConstants.REQCOL_HEADING_LIST);
			ui.access(() -> progressBar.setValue(0.4f));
			List<FinancialChartModel> financialChartList = excelReader.setDetailsToFinancialModel(excelMatrix);
			String[][] excelMatrix2 = excelReader.getspecificColFromExcel(wbInput,
					ExcelConstants.SHEET_HEADCOUNT_PAYROLL, ExcelConstants.REQCOL_HEADING_LIST2);
			ui.access(() -> progressBar.setValue(0.5f));
			List<HeadCountPayrollModel> headCountPayrollModel = excelReader.setDetailsToHeadCount(excelMatrix2);
			String[][] excelMatrix3 = excelReader.getspecificColFromExcel(wbInput, ExcelConstants.SHEET_UTILIZATION,
					ExcelConstants.REQCOL_HEADING_LIST3);
			List<UtilizationModel> utilizationModel = excelReader.setDetailsToUtilization(excelMatrix3);
			ui.access(() -> progressBar.setValue(0.7f));
			List<Employee> employeeList = excelReader.setDetailsToEmployee(headCountPayrollModel, utilizationModel);
			List<Customer> customers = excelReader.setDetailsToCustomerObj(financialChartList, employeeList);
			System.out.println("customers : "+customers);
			out=excelWriter.buildExcel(customers);
			outputFile=out;
			ui.access(() -> progressBar.setValue(0.8f));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			progressBar.setCaption("Completed");
			ui.access(() ->{ progressBar.setValue(1.0f);
			tick.setVisible(true);
			downloadBtn.setVisible(true);
			detailViewBtn.setVisible(true);
			});
			
			
				} catch (IOException e) {
					cross.setVisible(true);
					e.printStackTrace();
				}
				}
			
			}.start();
			
			
		
		return null;
		
	}

	public StreamResource createResource() {

		return new StreamResource(new StreamSource() {
			@Override
			public InputStream getStream() {
				try {
					return new FileInputStream(outputFile);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				return null;

			}

		}, "CPWorkBookOut.xlsx");
	}
	
	

}
