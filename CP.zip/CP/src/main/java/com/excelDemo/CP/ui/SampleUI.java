package com.excelDemo.CP.ui;

import org.springframework.beans.factory.annotation.Autowired;

import com.vaadin.annotations.Push;
import com.vaadin.annotations.Theme;
import com.vaadin.annotations.Viewport;
import com.vaadin.icons.VaadinIcons;
import com.vaadin.navigator.Navigator;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.spring.navigator.SpringViewProvider;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.UI;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Main UI class of the application that shows either the login screen or the
 * main view of the application depending on whether a user is signed in.
 *
 * The @Viewport annotation configures the viewport meta tags appropriately on
 * mobile devices. Instead of device based scaling (default), using responsive
 * layouts.
 */
@Viewport("user-scalable=no,initial-scale=1.0")
@Theme("mytheme")
@SpringUI
// @Push
public class SampleUI extends UI {

	/*
	 * @Autowired private AccessControl accessControl;
	 */
	
	@Autowired
	private SpringViewProvider viewProvider;

	private Menu menu;

	HorizontalLayout mainLayout = new HorizontalLayout();

	CssLayout viewContainer = new CssLayout();

	
	@Override
	protected void init(VaadinRequest vaadinRequest) {
		System.out.println("SampleUI int entry***********************************************************");
		Responsive.makeResponsive(this);
		setLocale(vaadinRequest.getLocale());
		getPage().setTitle("My");
		System.out.println("SampleUI before set content $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ ");

		setContent(new LoginScreen(this::showMainView));

	}

	protected void showMainView() {
		System.out.println("showMainView entry");

		addStyleName(ValoTheme.UI_WITH_MENU);

		setContent(mainLayout);

		mainLayout.setStyleName("main-screen");

		viewContainer.addStyleName("valo-content");
		viewContainer.setSizeFull();
		Navigator navigator = new Navigator(this, viewContainer);

		navigator.addProvider(viewProvider);
		navigator.setErrorView(ErrorView.class);
		menu = new Menu(navigator);
		// View are registered automatically by Vaadin Spring support
		menu.addViewButton(SampleCrudView.VIEW_NAME, SampleCrudView.VIEW_NAME, VaadinIcons.EDIT);
		menu.addViewButton(CPUploadView.VIEW_NAME, CPUploadView.VIEW_NAME, VaadinIcons.ARROW_CIRCLE_UP);
		menu.addViewButton(AboutView.VIEW_NAME, AboutView.VIEW_NAME, VaadinIcons.INFO_CIRCLE);

		navigator.addViewChangeListener(new ViewChangeHandler());

		mainLayout.addComponent(menu);
		mainLayout.addComponent(viewContainer);
		mainLayout.setExpandRatio(viewContainer, 1);
		mainLayout.setSizeFull();
		mainLayout.setSpacing(false);

		navigator.navigateTo(SampleCrudView.VIEW_NAME);
	}

	protected void navigateTo(String viewName) {
		Navigator navigator = new Navigator(this, viewContainer);
		navigator.addProvider(viewProvider);
		
		navigator.setErrorView(ErrorView.class);

		System.out.println("navigateTo entry");
		menu.setActiveView(viewName);
		navigator.navigateTo(viewName);
		
	}

	public static SampleUI get() {
		return (SampleUI) UI.getCurrent();
	}

	private class ViewChangeHandler implements ViewChangeListener {

		@Override
		public boolean beforeViewChange(ViewChangeEvent event) {
			return true;
		}

		@Override
		public void afterViewChange(ViewChangeEvent event) {
			menu.setActiveView(event.getViewName());
		}

	};

}
