package com.excelDemo.CP.model;

public class HeadCountPayrollModel {

	private String custId;
	private String projectId;
	private String associateId;
	private String associateName;
	private String gradeDesc;
	private String prollPerMonth;
	private String prollRegion;
	private String billability;
	private String monthYear;
	
	public HeadCountPayrollModel(String custId,String monthYear, String projectId, String billability, String associateId, String associateName,
			String gradeDesc, String prollRegion, String prollPerMonth) {
		super();
		this.custId = custId.trim();
		this.projectId = projectId.trim();
		this.associateId = associateId.trim();
		this.associateName = associateName.trim();
		this.gradeDesc = gradeDesc.trim();
		this.prollPerMonth = prollPerMonth.trim();
		this.prollRegion = prollRegion.trim();
		this.billability = billability.trim();
		this.monthYear = monthYear.trim();
	}
	
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getAssociateId() {
		return associateId;
	}
	public void setAssociateId(String associateId) {
		this.associateId = associateId;
	}
	public String getAssociateName() {
		return associateName;
	}
	public void setAssociateName(String associateName) {
		this.associateName = associateName;
	}
	public String getGradeDesc() {
		return gradeDesc;
	}
	public void setGradeDesc(String gradeDesc) {
		this.gradeDesc = gradeDesc;
	}
	public String getProllPerMonth() {
		return prollPerMonth;
	}
	public void setProllPerMonth(String prollPerMonth) {
		this.prollPerMonth = prollPerMonth;
	}
	public String getProllRegion() {
		return prollRegion;
	}
	public void setProllRegion(String prollRegion) {
		this.prollRegion = prollRegion;
	}
	public String getBillability() {
		return billability;
	}
	public void setBillability(String billability) {
		this.billability = billability;
	}
	public String getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	@Override
	public String toString() {
		return "HeadCountPayrollModel [custId=" + custId + ", projectId=" + projectId + ", associateId=" + associateId
				+ ", associateName=" + associateName + ", gradeDesc=" + gradeDesc + ", prollPerMonth=" + prollPerMonth
				+ ", prollRegion=" + prollRegion + ", billability=" + billability + ", monthYear=" + monthYear + "]";
	}
	
	
}
