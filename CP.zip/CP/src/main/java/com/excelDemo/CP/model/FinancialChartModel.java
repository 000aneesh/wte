package com.excelDemo.CP.model;

public class FinancialChartModel {


	private String custId;
	private String custDesc;
	private String monthYear;
	private String projId;
	private String projDesc;
	private String cprAccHead;
	private String accMidHeadgrp;
	private String actuals;
	
	
	public FinancialChartModel(String custId, String custDesc, String monthYear, String projId, String projDesc, String cprAccHead,
			String accMidHeadgrp, String actuals) {
		super();
		this.custId = custId.trim();
		this.custDesc = custDesc.trim();
		this.projId = projId.trim();
		this.projDesc = projDesc.trim();
		this.cprAccHead = cprAccHead.trim();
		this.accMidHeadgrp = accMidHeadgrp.trim();
		this.monthYear = monthYear.trim();
		this.actuals = actuals.trim();
	}
	
	public FinancialChartModel() {
			super();
		}

	@Override
	public String toString() {
		return "FinancialChartModel [custId=" + custId + ", custDesc=" + custDesc + ", monthYear=" + monthYear
				+ ", projId=" + projId + ", projDesc=" + projDesc + ", cprAccHead=" + cprAccHead + ", accMidHeadgrp="
				+ accMidHeadgrp + ", actuals=" + actuals + "]";
	}

	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustDesc() {
		return custDesc;
	}
	public void setCustDesc(String custDesc) {
		this.custDesc = custDesc;
	}
	public String getProjId() {
		return projId;
	}
	public void setProjId(String projId) {
		this.projId = projId;
	}
	public String getProjDesc() {
		return projDesc;
	}
	public void setProjDesc(String projDesc) {
		this.projDesc = projDesc;
	}
	public String getCprAccHead() {
		return cprAccHead;
	}
	public void setCprAccHead(String cprAccHead) {
		this.cprAccHead = cprAccHead;
	}
	public String getAccMidHeadgrp() {
		return accMidHeadgrp;
	}
	public void setAccMidHeadgrp(String accMidHeadgrp) {
		this.accMidHeadgrp = accMidHeadgrp;
	}
	public String getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
	public String getActuals() {
		return actuals;
	}
	public void setActuals(String actuals) {
		this.actuals = actuals;
	}
	
	
}
